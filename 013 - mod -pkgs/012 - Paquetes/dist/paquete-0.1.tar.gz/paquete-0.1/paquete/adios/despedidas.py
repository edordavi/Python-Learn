def despedirse():
    print('Adios, me estoy despidiendo desde la funcion despedirse del modulo despedidas')

class Despedida():
    def __init__(self):
        print("Adios. Me despido desde el init de la clase despedida")