from setuptools import setup

setup(
    name='paquete',
    version='0.1',
    description='Este es un paquete de ejemplo',
    author='Emil Ordonez',
    author_email='emil.ordonez@gmail.com',
    url='https://github.com/edordavi',
    scripts=[],
    packages=['paquete','paquete.adios','paquete.hola']
)

